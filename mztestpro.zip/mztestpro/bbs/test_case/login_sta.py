from time import sleep
import unittest, random, sys
sys.path.append(". /models")
sys.path.append(". /page_obj")
from models import myunit, function
from page_obj.loginPage import login


class loginTest(myunit.MyTest):
    def user_login_verify(self, username="", password=""):
        login(self.driver).user_login(username, password)

    def test_login1(self):
        self.user_login_verify()
        po = login(self.driver)
        self.assertEqual(po.user_error_hint(), "Login is empty.")
        self.asssertEqual(po.pwd_error_hint(), "Password is empty.")
        function.insert_img(self.driver, "user_pawd_empty.jpg")